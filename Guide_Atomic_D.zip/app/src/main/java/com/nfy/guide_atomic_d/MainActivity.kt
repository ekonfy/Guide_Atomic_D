package com.nfy.guide_atomic_d

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import com.nfy.guide_atomic_d.ui.theme.Guide_Atomic_DTheme

// Atoms
@Composable
fun AtomButton(text: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    // In a real app, this would be a more complex button composable
    Text(text = text, modifier = modifier)
}

@Composable
fun AtomInput(label: String, modifier: Modifier = Modifier) {
    // In a real app, this would be an OutlinedTextField or similar
    Text(text = "$label: ", modifier = modifier) // Placeholder
}

// Molecules
@Composable
fun MoleculeLoginInput(modifier: Modifier = Modifier) {
    AtomInput(label = "Username", modifier = modifier)
    AtomInput(label = "Password", modifier = modifier)
}

@Composable
fun MoleculeLoginButton(modifier: Modifier = Modifier) {
    AtomButton(text = "Login", onClick = { /* TODO: Implement login */ }, modifier = modifier)
}

// Organisms
@Composable
fun OrganismLoginForm(modifier: Modifier = Modifier) {
    MoleculeLoginInput(modifier = modifier)
    MoleculeLoginButton(modifier = modifier.padding(top = 16.dp))
}

// Templates (or Pages)
@Composable
fun TemplateLoginScreen(modifier: Modifier = Modifier) {
    OrganismLoginForm(modifier = modifier)
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState) // Enable edge-to-edge display
        enableEdgeToEdge()
        setContent {
            Guide_Atomic_DTheme {
                // Use the TemplateLoginScreen as the main content
                Scaffold(modifier = Modifier.fillMaxSize()) {
                    TemplateLoginScreen(modifier = Modifier.padding(it))
                }
            }
        }
    }
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
    Guide_Atomic_DTheme {
        Greeting("Android")
    }
}

// Keep the original Greeting function for preview purposes if needed
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
    Text(
        text = "Hello $name!",
        modifier = modifier
    )
}
